"""
Command line tests
"""
