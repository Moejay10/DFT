"""
IO for LAMMPS
"""
