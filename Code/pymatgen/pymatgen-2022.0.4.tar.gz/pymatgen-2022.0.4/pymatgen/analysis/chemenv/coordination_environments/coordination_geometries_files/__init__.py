"""
Coordination geometry files.
"""
