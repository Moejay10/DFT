"""
Modules for prediciting theoretical solar-cell efficiency
"""
