"""
Package for analyzing ferroelectricity.
"""
