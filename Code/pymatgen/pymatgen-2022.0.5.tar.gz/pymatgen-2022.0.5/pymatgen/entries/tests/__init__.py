"""
tests for pymatgen.entries
"""
